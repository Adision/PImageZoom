//
//  PZoomImage.h
//  PImageZoom
//
//  Created by Apple on 2017/4/11.
//  Copyright © 2017年 Apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PZoomImage : UIScrollView

-(instancetype)initWithFrame:(CGRect)frame imageCount:(NSInteger)imageCount;

@end
